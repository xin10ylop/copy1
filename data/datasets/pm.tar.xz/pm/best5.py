# One account only: the best 5 handles from scratch (greedy, as next5.py) against the current 5, and each current
# handle's own contribution (calls lost when it is dropped).
import json, collections
exec(open("next5.py").read().split("cand = collections.Counter")[0])
cand = collections.Counter(au(int(r["sid"])) for r in feats if r["sid"] and int(r["sid"]) in TW)
cand = [a for a, n in cand.most_common(120) if a]
def gain(s): n, right, big, m = score(s); return right - 0.5 * (n - right)
print("current 5:", score(CUR))
for a in sorted(CUR):
    print(f"   without {a:16s}: {score(CUR - {a})}")
cur = set(); 
for step in range(5):
    best = max((a for a in cand if a not in cur), key=lambda a: gain(cur | {a}))
    cur.add(best); print(f"+ {best:16s} {score(cur)}  Oct 24 only: {score(cur, lambda x: x['day'] == 24)}")
print("current 5, Oct 24 only:", score(CUR, lambda x: x["day"] == 24))
