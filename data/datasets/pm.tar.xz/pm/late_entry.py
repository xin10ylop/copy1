# "Buy only first coins, after the verdict": a 0.5 SOL market buy at the start of slot create+K (after every trade of the
# slots before), the later trades replayed on the curve with our buy in it, all sold at create+H. Both pump fees; net of
# our tips (tip 3M on the buy, 0.5M + 1M on the sell, base fees: 4.7 mSOL). First coins only; then copies for contrast.
import sys, json, glob, random, collections
sys.path.insert(0, "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad/pm")
import bt
SP = bt.SP; FEE = 0.0125; S = 0.5e9; TIPS = 0.0047 / 0.5
U = {x["mint"]: x for x in json.load(open(SP + "/pm/bt_rows.json"))}
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
def late(seq, cs, K, H, stake=S):
    before = [e for e in seq if e[0] < cs + K]
    if not before: return None
    vs, vt = before[-1][6], before[-1][7]          # state after the last trade before slot cs+K
    k = vs * vt; s = stake / (1 + FEE); x = vs + s; y = k / x; q = vt - y
    for s_, i, u, b, sol, tok, v1, v2, f in seq:
        if s_ < cs + K or s_ > cs + H: continue
        kk = x * y
        if b: x += sol; y = kk / x
        else: y += tok; x = kk / y
    out = (x - x * y / (y + q)) * (1 - FEE)
    return out / stake - 1
res = collections.defaultdict(list)
for p in glob.glob(SP + "/full/*.json"):
    if p.endswith(".tmp"): continue
    t = json.load(open(p)); x = U.get(t["mint"])
    if not x: continue
    c = cr[t["mint"]]
    seq = [(s, i, u, bool(b), sol, tok, vs, vt, f) for s, i, sg, evs in t["rows"] for (u, b, sol, tok, vs, vt, f) in evs]
    cls = "first" if x["first_fresh"] else "not first"
    for K in (2, 3, 4, 5):
        for H in (10, 12):
            v = late(seq, c["slot"], K, H)
            if v is not None: res[(cls, K, H, x["day"], x["hour"] >= 12)].append(v - TIPS)
def agg(cls, K, H, sel=lambda d, pm: True):
    v = [a for (c, k, h, d, pm), vs in res.items() if c == cls and k == K and h == H and sel(d, pm) for a in vs]
    if len(v) < 5: return "n<5"
    m = sum(v) / len(v); random.seed(5); bs = sorted(sum(random.choice(v) for _ in v) / len(v) for _ in range(600))
    return f"{100*m:+6.2f}% [{100*bs[15]:+6.2f},{100*bs[584]:+6.2f}] n {len(v):4d}"
for cls in ("first", "not first"):
    print(f"== {cls} coins: buy at the start of create+K, sell at create+H, net of pump fees and our tips")
    for K in (2, 3, 4, 5):
        for H in (10, 12):
            print(f"   K{K} H{H}: all {agg(cls,K,H)} | Oct23 AM {agg(cls,K,H,lambda d,pm: d==23 and not pm)} | Oct23 PM {agg(cls,K,H,lambda d,pm: d==23 and pm)} | Oct24 AM {agg(cls,K,H,lambda d,pm: d==24)}")
