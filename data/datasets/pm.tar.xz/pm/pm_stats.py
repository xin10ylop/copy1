# The tweet rule on Oct 23 by part of the day: no check / "exit" / "on", net of our 1.77% cost, hold 10 slots.
# Deployer list = a creator or signer he traded in the 7 days before the coin (signers known only for decoded creates).
import json, glob, random, collections, bisect, sys
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
DAYS = [int(d) for d in (sys.argv[1:] or ["23"])]
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
DC = collections.defaultdict(list); DS = collections.defaultdict(list)
for t in json.load(open(SP + "/month/AHwJ_T.json")):
    if t["stake"] < 0.1: continue
    DC[t["creator"]].append(t["bt"])
    if t["mint"] in cr: DS[cr[t["mint"]]["signer"]].append(t["bt"])
for d in (DC, DS):
    for v in d.values(): v.sort()
n_in = lambda d, k, lo, hi: bisect.bisect_left(d.get(k, []), hi) - bisect.bisect_left(d.get(k, []), lo)
TOOLS = ("metadata.j7tracker.io", "meta.uxento.io", "m.rapidlaunch.io")
TEMPLATE = lambda d: (0.95 <= d < 1.05) or (2.95 <= d < 4.05) or (4.95 <= d < 5.05) or d >= 7
COST = 0.0177
def stats(v):
    v = [x - COST for x in v]
    if len(v) < 5: return f"n {len(v)}"
    m = sum(v) / len(v); random.seed(5)
    bs = sorted(sum(random.choice(v) for _ in v) / len(v) for _ in range(1000))
    return f"{100*m:+6.2f}% [{100*bs[25]:+6.2f},{100*bs[974]:+6.2f}] win {100*sum(x > 0 for x in v)/len(v):3.0f}% n {len(v):3d}"
for day in DAYS:
    rows = json.load(open(SP + f"/univ/rows_{day}.json"))
    bt = {r["mint"]: r["bt"] for r in json.load(open(SP + ("/univ/dataset.json" if day == 24 else f"/univ/dataset_{day}.json")))}
    R = []
    for x in rows:
        c = cr.get(x["mint"]); t = bt.get(x["mint"])
        if not c or t is None or x["host"] not in TOOLS or not TEMPLATE(x["dev"]): continue
        if not (x["pb_sol"] is None or x["pb_sol"] <= 40): continue
        if n_in(DC, c["creator"], t - 7 * 86400, t) + n_in(DS, c["signer"], t - 7 * 86400, t) == 0: continue
        if x.get("v10") is None: continue
        x["g"] = x["first"] and x["fresh"]; R.append(x)
    print(f"== Oct {day}: deployer-list coins (tool host, template dev buy, post-bundle <= 40 SOL), hold 10, net of our 1.77%")
    print(f"   {'hours':10s} {'coins/h':>7s}  {'no check (buy all)':44s} {'exit: copy sold at +1 slot':44s} {'exit, copy sold at +3':44s} {'on: first coin only':44s}  first-spot taker")
    for lab, lo, hi in (("00-06", 0, 6), ("06-12", 6, 12), ("12-18", 12, 18), ("18-24", 18, 24), ("00-12", 0, 12), ("12-24", 12, 24)):
        G = [x for x in R if lo <= x["hour"] < hi]
        if not G: continue
        allv = [x["v10"] for x in G]
        ex1 = [x["v10"] if x["g"] else (x.get("v1") if x.get("v1") is not None else x["v10"]) for x in G]
        ex3 = [x["v10"] if x["g"] else (x.get("v3") if x.get("v3") is not None else x["v10"]) for x in G]
        on = [x["v10"] for x in G if x["g"]]
        who = collections.Counter(x["who"] for x in G)
        print(f"   {lab:10s} {len(G)/(hi-lo):7.1f}  {stats(allv):44s} {stats(ex1):44s} {stats(ex3):44s} {stats(on):44s}  {dict(who)}")
    print("   by hour (no check | exit +1 | first coins only):")
    for h in range(24):
        G = [x for x in R if x["hour"] == h]
        if len(G) < 5: continue
        ex1 = [x["v10"] if x["g"] else (x.get("v1") if x.get("v1") is not None else x["v10"]) for x in G]
        print(f"     {h:02d}  {stats([x['v10'] for x in G]):44s} {stats(ex1):44s} {stats([x['v10'] for x in G if x['g']])}")
