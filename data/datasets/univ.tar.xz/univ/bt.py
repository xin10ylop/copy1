# Rule backtest on realized first-buyer outcomes (create + H slots, before tips), weighted for the skipped sample.
#   python3 -I univ/bt.py [H]
import json, os, math, collections, statistics as St, random, sys
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
H = int(sys.argv[1]) if len(sys.argv) > 1 else 10
R = json.load(open(SP + "/univ/dataset.json")); FB = json.load(open(SP + f"/univ/fb{H}.json"))
TW = {}
for f in os.listdir(SP + "/univ/tweets"):
    j = json.load(open(SP + "/univ/tweets/" + f))
    if j.get("code") == 200: TW[f[:-5]] = j
U = [r for r in R if r["sid"] and r["dev"] >= 0.95 and r["delay"] is not None and r["delay"] < 3600]
skipped = [r for r in U if not r["he"]]
s_with = [r for r in skipped if r["mint"] in FB]
W_SKIP = len(skipped) / max(len(s_with), 1)
def feat(r):
    t = TW.get(r["sid"]) or {}; a = t.get("author") or {}; q = t.get("quote") or {}
    return dict(fol=a.get("followers"), ver=a.get("verified"), reply=bool(t.get("replying_to")), quote=bool(q and q.get("screen_name")), media=t.get("has_media"))
rows = []
for r in U:
    if r["mint"] not in FB: continue
    x = dict(r); x.update(feat(r)); x["out"] = FB[r["mint"]]["ret"]; x["w"] = 1.0 if r["he"] else W_SKIP
    rows.append(x)
print(f"H = {H} slots | universe {len(U)} (he attempted {len(U) - len(skipped)}, skipped {len(skipped)}); outcomes: all his attempts with a tape + "
      f"{len(s_with)} sampled skipped (weight {W_SKIP:.1f})")
TEMPLATE = lambda d: (0.95 <= d < 1.05) or (2.95 <= d < 4.05) or (4.95 <= d < 5.05) or d >= 7
RULES = {
    "R0 all (fresh tweet coin, dev >= 1)": lambda x: True,
    "R1 dev template": lambda x: TEMPLATE(x["dev"]),
    "R2 template + tweet 2-10 s": lambda x: TEMPLATE(x["dev"]) and 2 <= x["delay"] < 10,
    "R3 template + author <= 10k + not reply": lambda x: TEMPLATE(x["dev"]) and (x["fol"] or 0) <= 10000 and not x["reply"],
    "R4 R3 + tool host": lambda x: TEMPLATE(x["dev"]) and (x["fol"] or 0) <= 10000 and not x["reply"] and x["host"] in ("metadata.j7tracker.io", "meta.uxento.io", "m.rapidlaunch.io"),
    "R5 R4 + first coin of its tweet": lambda x: TEMPLATE(x["dev"]) and (x["fol"] or 0) <= 10000 and not x["reply"] and x["host"] in ("metadata.j7tracker.io", "meta.uxento.io", "m.rapidlaunch.io") and x["tweet_rank"] == 1,
    "R6 R4 + deployer launched earlier today": lambda x: TEMPLATE(x["dev"]) and (x["fol"] or 0) <= 10000 and not x["reply"] and x["host"] in ("metadata.j7tracker.io", "meta.uxento.io", "m.rapidlaunch.io") and x["creator_prior"] >= 1,
    "D1 his followed deployers (5+ attempts today)": lambda x: x["creator_prior_he"] >= 5,
    "D2 his picks (benchmark, not usable live)": lambda x: x["he"],
}
def wstats(G, cost):
    if not G: return None
    w = [x["w"] for x in G]; v = [x["out"] - cost for x in G]; sw = sum(w)
    m = sum(a * b for a, b in zip(w, v)) / sw
    win = sum(a for a, b in zip(w, v) if b > 0) / sw
    srt = sorted(zip(v, w)); acc = 0; med = srt[-1][0]
    for b, a in srt:
        acc += a
        if acc >= sw / 2: med = b; break
    random.seed(1); bs = []
    for _ in range(300):
        smp = [random.choice(G) for _ in G]; ws = sum(x["w"] for x in smp); bs.append(sum(x["w"] * (x["out"] - cost) for x in smp) / ws)
    bs.sort()
    return m, bs[7], bs[292], med, win, sw
for split, sel in (("TRAIN hours 0-7", lambda x: x["hour"] < 8), ("TEST hours 8-11", lambda x: x["hour"] >= 8)):
    print(f"\n== {split}  (net = first buyer's realized result minus a {0.75}% round trip at his cost level)")
    print(f"   {'rule':46s} {'coins/h':>7s} {'mean':>7s} {'95% CI':>17s} {'median':>7s} {'win':>4s}")
    hours = len({x['hour'] for x in rows if sel(x)})
    for name, f in RULES.items():
        G = [x for x in rows if sel(x) and f(x)]
        s = wstats(G, 0.0075)
        if s: print(f"   {name:46s} {s[5]/hours:7.1f} {100*s[0]:+6.2f}% [{100*s[1]:+6.2f},{100*s[2]:+6.2f}] {100*s[3]:+6.2f}% {100*s[4]:3.0f}%")
