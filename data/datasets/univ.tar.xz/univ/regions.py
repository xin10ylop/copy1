# Leader region of each rule coin's create slot (the Frankfurt box fires only with EU leaders): how many of the deployer-list
# coins a second box elsewhere would add. Slot leaders from getSlotLeaders (Triton), regions from data/leader_regions.json.
import json, glob, sys, collections, bisect
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/month"); import tri
REG = json.load(open("/home/user/rugsnipe/data/leader_regions.json"))["regions"]
L = json.load(open(SP + "/univ/speed_rows.json"))
cr = {}
for f in glob.glob(SP + "/univ/creates_*.json"):
    for c in json.load(open(f)): cr[c["mint"]] = c
slots = sorted(cr[x["mint"]]["slot"] for x in L)
leader = {}
lo, hi = slots[0], slots[-1]
s = lo
while s <= hi:
    k = bisect.bisect_left(slots, s)
    if k >= len(slots): break
    s = slots[k]
    try:
        ls = tri.rpc("getSlotLeaders", [s, 5000])
    except Exception as e:
        print("getSlotLeaders failed at", s, tri.red(e)[:120]); break
    for i, pk in enumerate(ls or []): leader[s + i] = pk
    s += 5000
reg = collections.Counter(); wins = collections.Counter(); raced_reg = collections.Counter(); val = collections.defaultdict(list)
for x in L:
    sl = cr[x["mint"]]["slot"]; pk = leader.get(sl); r = REG.get(pk, "unknown") if pk else "no leader"
    reg[r] += x["w"]
    if x.get("who") == "us": wins[r] += 1
print(f"deployer-list coins by the create slot's leader region (weighted, both days, 00-12 UTC): total {sum(reg.values()):.0f}")
for r, w in reg.most_common(): print(f"   {r:9s} {w:6.0f}  {w/sum(reg.values()):.0%}   our first spots (Oct 24) {wins[r]}")
