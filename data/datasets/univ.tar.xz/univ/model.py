# His second-layer choice: univariate attempt rates, then a small decision tree (train hours < SPLIT, test >= SPLIT),
# judged by agreement with him and by the first-spot value of what it picks.
import json, math, collections, statistics as St, sys
import numpy as np
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
SPLIT = int(sys.argv[1]) if len(sys.argv) > 1 else 8
R = json.load(open(SP + "/univ/dataset.json"))
U = [r for r in R if r["has_early"] and r["sid"] and r["dev"] >= 0.95 and r["delay"] is not None and r["delay"] < 3600]
extra = [r for r in R if r["he"] and r["has_early"] and r not in U]
print(f"universe (fresh tweet coins, dev >= 1 SOL, early trades): {len(U)}; he attempted {sum(1 for r in U if r['he'])} of them; his attempts outside it: {len(extra)}")
def ci(v):
    v = [x for x in v if x is not None]
    if len(v) < 2: return f"n={len(v)}"
    m = St.mean(v); h = 1.96 * St.pstdev(v) / math.sqrt(len(v)); return f"n={len(v):4d} {100*m:+6.2f}% [{100*(m-h):+6.2f},{100*(m+h):+6.2f}]"
print("first-spot value at +6 slots: he attempted", ci([r["v6"] for r in U if r["he"]]), "| skipped", ci([r["v6"] for r in U if not r["he"]]), "| all", ci([r["v6"] for r in U]))
def bucket(name, f, edges):
    print(f"\n{name}: bucket  attempted/n  rate | value(attempted) | value(skipped)")
    for lo, hi in zip(edges[:-1], edges[1:]):
        G = [r for r in U if f(r) is not None and lo <= f(r) < hi]
        if G: print(f"   {lo:>8}-{hi:<8} {sum(1 for r in G if r['he']):4d}/{len(G):<4d} {100*sum(1 for r in G if r['he'])/len(G):5.1f}% | {ci([r['v6'] for r in G if r['he']])} | {ci([r['v6'] for r in G if not r['he']])}")
def cat(name, f, top=8):
    print(f"\n{name}: value  attempted/n  rate | value(attempted) | value(skipped)")
    c = collections.Counter(f(r) for r in U)
    for k, n in c.most_common(top):
        G = [r for r in U if f(r) == k]
        print(f"   {str(k)[:26]:26s} {sum(1 for r in G if r['he']):4d}/{n:<4d} {100*sum(1 for r in G if r['he'])/n:5.1f}% | {ci([r['v6'] for r in G if r['he']])} | {ci([r['v6'] for r in G if not r['he']])}")
cat("launch tool", lambda r: r["host"]); cat("image host", lambda r: r["img"])
bucket("tweet -> coin delay (s)", lambda r: r["delay"], [-1e9, 3, 10, 30, 60, 180, 600, 3600])
bucket("coins for this tweet before this one", lambda r: r["tweet_rank"] - 1, [0, 1, 2, 3, 5, 100])
bucket("he attempted an earlier coin of this tweet", lambda r: r["tweet_prior_he"], [0, 1, 100])
bucket("dev buy (SOL)", lambda r: r["dev"], [0.95, 1.05, 2, 2.95, 3.05, 4, 5.05, 100])
bucket("bundle txs after the create", lambda r: r.get("nb"), [0, 1, 2, 3, 4, 10])
bucket("post-bundle reserve (vSOL)", lambda r: r.get("post_vs"), [0, 33, 36, 38, 40, 45, 100])
bucket("creator's earlier launches today", lambda r: r["creator_prior"], [0, 1, 3, 10, 1000])
bucket("he attempted the creator's earlier launches today", lambda r: r["creator_prior_he"], [0, 1, 3, 1000])
bucket("his month trades with this creator before", lambda r: r["month_n"], [0, 1, 5, 20, 10000])
bucket("author's earlier coins today", lambda r: r["author_prior"], [0, 1, 3, 10, 1000])
bucket("hour (UTC)", lambda r: r["hour"], list(range(0, 13)))
cat("website", lambda r: r["website"]); cat("description", lambda r: r["desc"]); cat("community link", lambda r: r["community"])
json.dump([r["mint"] for r in U], open(SP + "/univ/universe_mints.json", "w"))
