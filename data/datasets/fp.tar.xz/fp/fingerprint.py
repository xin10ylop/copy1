# One operator's launches (signer's creates over the last H hours): template (dev buy, bundle buys), when the creator set
# sold, follower flow, and the P&L of a 0.5 SOL buyer placed right behind the bundle for holds 1..15 slots.
#   python3 fingerprint.py SIGNER [HOURS]   -> fp/<signer8>.json + a summary
import sys, json, time, struct, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/rivalpnl")
import common as C, pumpparse as PP
C.MIN_GAP = 0.21
W = "4g49xGbgHZk3QYR1o6QSfDUbHmJZFwN6iDp6Vco1skff"; A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"
SIGNER = sys.argv[1]; HOURS = float(sys.argv[2]) if len(sys.argv) > 2 else 48
STAKE, FEE, COSTS = 0.5, 0.0125, 0.0094      # our stake, pump's fee each way, our tips + tx fees per round trip (SOL)
HOLDS = list(range(1, 16))
def sigs(addr, since):
    out, before = [], None
    while True:
        opt = {"limit": 1000}
        if before: opt["before"] = before
        page = C.rpc("getSignaturesForAddress", [addr, opt], cache=False) or []
        if not page: break
        out += page; before = page[-1]["signature"]
        if page[-1].get("blockTime", 0) < since or len(page) < 1000: break
    return [s for s in out if s.get("blockTime", 0) >= since and s.get("err") is None]
def tx(sig):
    return C.rpc("getTransaction", [sig, {"encoding": "json", "commitment": "confirmed", "maxSupportedTransactionVersion": 1}])
def strs(b, n):
    out, o = [], 0
    for _ in range(n):
        if o + 4 > len(b): break
        l = struct.unpack_from("<I", b, o)[0]; o += 4
        out.append(b[o:o + l].decode("utf8", "replace")); o += l
    return out
def create_of(t):
    ks = PP.keys_of(t)
    for prog, accs, data, parsed, oi, inner in PP._ixs(t, ks):
        if prog == C.PUMP and data and not inner and PP.IXR.get(data[:8], "").startswith("create"):
            s = strs(data[8:], 3)
            return accs[0] if accs else None, (s + [None, None, None])[:3]
    return None, None
since = time.time() - HOURS * 3600
launches, token = [], None
for _ in range(40):
    opt = {"transactionDetails": "full", "sortOrder": "desc", "limit": 100, "encoding": "json", "maxSupportedTransactionVersion": 1,
           "filters": {"blockTime": {"gte": int(since)}, "status": "succeeded"}}
    if token: opt["paginationToken"] = token
    r = C.rpc("getTransactionsForAddress", [SIGNER, opt], cache=False) or {}
    d = r.get("data") or []
    for t in d:
        if PP.keys_of(t)[0] != SIGNER: continue
        mint, meta = create_of(t)
        if mint: launches.append((mint, meta, t.get("blockTime") or 0, t["slot"]))
    token = r.get("paginationToken")
    if not token or len(d) < 100: break
rows = []
for mint, meta, bt, cslot in launches:
    txs, tok = [], None
    for _ in range(6):
        opt = {"transactionDetails": "full", "sortOrder": "asc", "limit": 100, "encoding": "json", "maxSupportedTransactionVersion": 1,
               "filters": {"status": "succeeded", "slot": {"lte": cslot + 16}}}
        if tok: opt["paginationToken"] = tok
        res = C.rpc("getTransactionsForAddress", [C.bonding_curve(mint), opt]) or {}
        d = res.get("data") or []
        txs += [t for t in d if t["meta"]["err"] is None]
        tok = res.get("paginationToken")
        if not tok or len(d) < 100: break
    if not txs: continue
    cs = txs[0]["slot"]
    ev = []   # (slot_off, idx, user, is_buy, sol, tok, vsol, vtok)
    for t in txs:
        if t["slot"] > cs + 16: break
        try: tr = [x for x in PP.analyze(t)["trades"] if x["mint"] == mint]
        except Exception: tr = []
        for x in tr: ev.append((t["slot"] - cs, t.get("transactionIndex", 0), x["user"], x["is_buy"], x["sol"], x["tok"], x["vsol"], x["vtok"]))
    if not ev: continue
    # the creator set: signer + the buys of the create slot chained to the create (index gap <= 2)
    cset, last_i, run = {SIGNER}, ev[0][1], []
    for e in ev:
        if e[0] != 0: break
        if e[1] - last_i > 2 and run: break
        if e[3]: cset.add(e[2]); run.append(e); last_i = e[1]
    if not run: continue
    dev = run[0][4] / 1e9; bundle = [e[4] / 1e9 for e in run[1:]]
    V, Tk = run[-1][6], run[-1][7]            # post-bundle virtual reserves (lamports, raw tokens)
    if not V or not Tk: continue
    after = [e for e in ev if (e[0], e[1]) > (run[-1][0], run[-1][1])]
    # the counterfactual: we take the first spot behind the bundle; the wallet that really took it is replaced by us
    first = next((e[2] for e in after if e[3] and e[2] not in cset), None)
    gone = {W, first} if first else {W}
    cs_sells = [e for e in after if e[2] in cset and not e[3]]
    first_dump = min((e[0] for e in cs_sells), default=None)
    dump_sol = sum(e[4] for e in cs_sells) / 1e9
    def pnl_at(h):
        # a 0.5 SOL buy right after the bundle; the later trades replayed at their own SOL (buys) / token (sells)
        # amounts on the constant-product curve; sold before any trade of slot +h
        v, tk = float(V), float(Tk)
        s_in = STAKE * 1e9 / (1 + FEE); v2 = v + s_in; q = tk - v * tk / v2; tk = v * tk / v2; v = v2
        for e in after:
            if e[0] >= h: break
            if e[2] in gone: continue                   # the real first buyer (and our own trade) is our position
            k = v * tk
            if e[3]:
                v = v + e[4]; tk = k / v
            else:
                tk = tk + e[5]; v = k / tk
        v_new = v * tk / (tk + q); out = (v - v_new) * (1 - FEE) / 1e9
        return out - STAKE - COSTS
    followers = sum(e[4] for e in after if e[3] and e[2] not in cset and e[0] <= 10 and e[2] not in gone) / 1e9
    rows.append(dict(mint=mint, t=bt, name=meta[0], sym=meta[1], uri=meta[2], dev=round(dev, 4), bundle=[round(b, 4) for b in bundle],
                     wallets=len(bundle), post_v=round(V / 1e9, 3), first_dump=first_dump, dump_sol=round(dump_sol, 3),
                     followers_sol=round(followers, 3), ahw=any(e[2] == A for e in after if e[3]), us=any(e[2] == W for e in after if e[3]),
                     first=first, first_is=('us' if first == W else 'ahw' if first == A else 'other' if first else 'none'),
                     pnl={h: round(pnl_at(h), 4) for h in HOLDS},
                     post_t=Tk, cset=sorted(cset), dev_wallet=SIGNER,
                     # every trade after the bundle: slot offset, index, role, buy?, SOL (lamports), tokens, vsol, vtok
                     ev=[[e[0], e[1], ('dev' if e[2] == SIGNER else 'bw' if e[2] in cset else 'us' if e[2] == W else 'ahw' if e[2] == A
                                       else 'first' if e[2] == first else 'o'), int(e[3]), e[4], e[5], e[6], e[7]] for e in after]))
json.dump(rows, open(f"{SP}/fp/{SIGNER[:8]}.json", "w"))
print(f"{SIGNER}: {len(rows)} launches in {HOURS:.0f} h")
if rows:
    ex = {h: st.mean(r["pnl"][h] for r in rows) for h in HOLDS}
    print("mean P&L per launch (SOL, after our costs) by hold:", "  ".join(f"{h}:{ex[h]:+.3f}" for h in HOLDS))
    dumps = collections.Counter(r["first_dump"] for r in rows)
    print("first creator-set sell, slot offset:", dict(sorted(((k if k is not None else 99), v) for k, v in dumps.items())))
    tm = collections.Counter((r["dev"], tuple(r["bundle"])) for r in rows)
    print("templates (dev, bundle buys): ", tm.most_common(6))
