# Do an operator's rugs come in streaks? P(rug | its previous launch rugged) against the base rate, and a cooldown rule
# (skip the operator for W minutes after a rug the bot could see) scored per day on rugs and on everything else.
import json, glob, os, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
V0, T0 = 30e9, 1_073_000_000e6
L = collections.defaultdict(list)
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if not R or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]; full = next((s for s in OPS if s.startswith(s8)), None)
    if not full: continue
    hold = int(OPS[full].get("hold_slots", 6))
    R = sorted([r for r in R if r["wallets"] >= 1], key=lambda r: r["t"])
    if not R: continue
    mid = R[0]["t"] + (R[-1]["t"] - R[0]["t"]) / 2
    for r in R:
        put = (r["dev"] + sum(r["bundle"])) * 1e9; bought = T0 - V0 * T0 / (V0 + put / 1.0125)
        rug = sum(e[5] for e in r["ev"] if e[2] in ("dev", "bw") and not e[3] and e[0] < hold) >= 0.6 * bought
        L[s8].append(dict(t=r["t"], rug=rug, pnl=r["pnl"][str(hold)], day=1 if r["t"] < mid else 2))
# streaks
after_rug = after_ok = rug_after_rug = rug_after_ok = 0
for s8, ls in L.items():
    for a, b in zip(ls, ls[1:]):
        if a["rug"]:
            after_rug += 1; rug_after_rug += b["rug"]
        else:
            after_ok += 1; rug_after_ok += b["rug"]
print(f"next launch rugs: after a rug {rug_after_rug}/{after_rug} ({100*rug_after_rug/max(1,after_rug):.0f}%), after a normal launch {rug_after_ok}/{after_ok} ({100*rug_after_ok/max(1,after_ok):.1f}%)")
# cooldown: a rug is visible ~hold slots after its create (< 10 s); skip the operator's launches created in the next W minutes
def run(W):
    out = {1: [0.0, 0.0, 0], 2: [0.0, 0.0, 0]}      # day -> [rug P&L kept, other P&L kept, skipped]
    for s8, ls in L.items():
        last_rug = None
        for l in ls:
            skip = W > 0 and last_rug is not None and l["t"] - last_rug < W * 60
            if skip: out[l["day"]][2] += 1
            else: out[l["day"]][0 if l["rug"] else 1] += l["pnl"]
            if l["rug"]: last_rug = l["t"] + 10
    return out
print(f"\n{'cooldown':<12}{'day1 rugs':>10}{'day1 rest':>10}{'day1 total':>11}{'day2 rugs':>10}{'day2 rest':>10}{'day2 total':>11}{'skipped':>8}")
for W in (0, 5, 15, 30, 60, 120):
    o = run(W)
    print(f"{('none (now)' if W == 0 else f'{W} min'):<12}{o[1][0]:>+10.3f}{o[1][1]:>+10.3f}{o[1][0]+o[1][1]:>+11.3f}{o[2][0]:>+10.3f}{o[2][1]:>+10.3f}{o[2][0]+o[2][1]:>+11.3f}{o[1][2]+o[2][2]:>8}")
