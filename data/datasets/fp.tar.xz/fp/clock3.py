# Per-operator clock with its own consistency check: an operator's hold moves to its clock hold only when that hold
# beat the table hold in BOTH fitting periods; the procedure is scored on a third, held-out period (3 rotations).
import json, glob, os, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
V0, T0 = 30e9, 1_073_000_000e6
ops = {}
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if not R or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]; full = next((s for s in OPS if s.startswith(s8)), None)
    if not full: continue
    R = sorted([r for r in R if r["wallets"] >= 1], key=lambda r: r["t"])
    if len(R) < 15: continue
    t0, t1 = R[0]["t"], R[-1]["t"]
    for r in R:
        put = (r["dev"] + sum(r["bundle"])) * 1e9; bought = T0 - V0 * T0 / (V0 + put / 1.0125)
        cum, r["ss"] = 0.0, None
        for e in r["ev"]:
            if e[2] in ("dev", "bw") and not e[3]:
                cum += e[5]
                if cum >= 0.25 * bought: r["ss"] = e[0]; break
        r["per"] = min(2, int(3 * (r["t"] - t0) / max(1, t1 - t0 + 1)))
    ops[s8] = (int(OPS[full].get("hold_slots", 6)), int(OPS[full].get("n", 0)), R)
def clock_hold(rs):
    ss = [r["ss"] for r in rs if r["ss"] is not None]
    if len(rs) < 5 or not ss or len(ss) / len(rs) < 1 / 3: return None
    return int(max(2, min(15, st.median(ss) - 1)))
tot = collections.Counter(); changes = collections.Counter()
for test in (0, 1, 2):
    fits = [p for p in (0, 1, 2) if p != test]
    for s8, (th, n, R) in ops.items():
        fr = [r for r in R if r["per"] in fits]; te = [r for r in R if r["per"] == test]
        h = clock_hold(fr)
        use = th
        if h is not None and h != th:
            ok = all(sum(r["pnl"][str(h)] for r in R if r["per"] == p) > sum(r["pnl"][str(th)] for r in R if r["per"] == p) for p in fits)
            if ok: use = h; changes[s8] += 1
        tot[("table", test)] += sum(r["pnl"][str(th)] for r in te)
        tot[("clock if both fitting periods agree", test)] += sum(r["pnl"][str(use)] for r in te)
        tot[("clock if both agree and his n < 5", test)] += sum(r["pnl"][str(use if n < 5 else th)] for r in te)
for name in ("table", "clock if both fitting periods agree", "clock if both agree and his n < 5"):
    vals = [tot[(name, p)] for p in (0, 1, 2)]
    print(f"{name:<38} held-out period 1 {vals[0]:+8.3f}   2 {vals[1]:+8.3f}   3 {vals[2]:+8.3f}   total {sum(vals):+8.3f}")
print("\noperators whose hold moved (in how many of the 3 rotations):", dict(changes.most_common()))
