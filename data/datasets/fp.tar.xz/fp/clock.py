# Each operator's clock: when its creator set starts selling for real (>= 25% of what it bought, cumulative) and when the
# first spot's value peaks. Exit rules from the clock read on one day, applied to the other day, against the table hold.
import json, glob, os, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
V0, T0 = 30e9, 1_073_000_000e6
H = range(1, 16)
ops = {}
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if not R or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]; full = next((s for s in OPS if s.startswith(s8)), None)
    if not full: continue
    R = sorted([r for r in R if r["wallets"] >= 1], key=lambda r: r["t"])
    if len(R) < 10: continue
    mid = R[0]["t"] + (R[-1]["t"] - R[0]["t"]) / 2
    for r in R:
        put = (r["dev"] + sum(r["bundle"])) * 1e9; bought = T0 - V0 * T0 / (V0 + put / 1.0125)
        cum, r["sell_slot"] = 0.0, None
        for e in r["ev"]:
            if e[2] in ("dev", "bw") and not e[3]:
                cum += e[5]
                if cum >= 0.25 * bought: r["sell_slot"] = e[0]; break
        r["peak"] = max(H, key=lambda h: r["pnl"][str(h)])
        r["day"] = 1 if r["t"] < mid else 2
        r["rug"] = sum(e[5] for e in r["ev"] if e[2] in ("dev", "bw") and not e[3] and e[0] < int(OPS[full].get("hold_slots", 6))) >= 0.6 * bought
    ops[s8] = (int(OPS[full].get("hold_slots", 6)), R)
def clock(rs):
    ss = [r["sell_slot"] for r in rs if r["sell_slot"] is not None]
    pk = [r["peak"] for r in rs]
    return (st.median(ss) if ss else None, len(ss) / len(rs), st.median(pk))
tot = collections.defaultdict(float); rows = []
for s8, (th, R) in ops.items():
    for fit, test in ((1, 2), (2, 1)):
        a = [r for r in R if r["day"] == fit]; b = [r for r in R if r["day"] == test]
        if len(a) < 5 or len(b) < 5: continue
        sell_med, sell_share, peak_med = clock(a)
        # A: sell one slot before the creator set's typical real sell (if it sells in at least a third of launches)
        hA = int(max(2, min(15, sell_med - 1))) if sell_med is not None and sell_share >= 1 / 3 else th
        # B: sell at the typical peak
        hB = int(max(1, min(15, round(peak_med))))
        for name, h in (("table hold", th), ("before their sell", hA), ("at their peak", hB)):
            v = sum(r["pnl"][str(h)] for r in b); rv = sum(r["pnl"][str(h)] for r in b if r["rug"])
            tot[(name, test, "all")] += v; tot[(name, test, "rugs")] += rv; tot[(name, test, "rest")] += v - rv
        rows.append((s8, fit, th, sell_med, sell_share, hA, peak_med, hB))
print(f"{len(ops)} table operators with >= 10 bundled launches")
print(f"\n{'exit rule (read on the other day)':<34}{'day 1 all':>10}{'rugs':>8}{'rest':>9}{'day 2 all':>11}{'rugs':>8}{'rest':>9}")
for name in ("table hold", "before their sell", "at their peak"):
    print(f"{name:<34}{tot[(name,1,'all')]:>+10.3f}{tot[(name,1,'rugs')]:>+8.3f}{tot[(name,1,'rest')]:>+9.3f}{tot[(name,2,'all')]:>+11.3f}{tot[(name,2,'rugs')]:>+8.3f}{tot[(name,2,'rest')]:>+9.3f}")
print("\nper operator, its clock read on each day (median slot of the creator set's real selling, share of launches where it sold, median peak):")
by = collections.defaultdict(dict)
for s8, fit, th, sm, sh, hA, pm, hB in rows: by[s8][fit] = (sm, sh, pm)
for s8, d in sorted(by.items()):
    def fmt(x): return "-" if x is None else f"s+{x[0] if x[0] is not None else '-'} ({100*x[1]:.0f}%), peak s+{x[2]}"
    print(f"  {s8}  hold {ops[s8][0]:>2}   day1: {fmt(d.get(1)):<30} day2: {fmt(d.get(2))}")
