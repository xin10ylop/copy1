# The best wallet's failed buys over the last 48 h -> the set of mints he attempted but did not land (fp/ahw_failed.json)
import sys, json, time
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/rivalpnl")
import common as C, pumpparse as PP
C.MIN_GAP = 0.21
A = "AHwJSnFNUiAU9FfT5ewW2osqMo938WtL7KhfsJyfpaN2"
since = int(time.time() - 49 * 3600)
mints, token, n = {}, None, 0
for _ in range(200):
    opt = {"transactionDetails": "full", "sortOrder": "desc", "limit": 100, "encoding": "json", "maxSupportedTransactionVersion": 1,
           "filters": {"blockTime": {"gte": since}, "status": "failed"}}
    if token: opt["paginationToken"] = token
    r = C.rpc("getTransactionsForAddress", [A, opt], cache=False) or {}
    d = r.get("data") or []
    for t in d:
        n += 1
        for k in PP.keys_of(t):
            if k.endswith("pump"): mints[k] = t.get("blockTime"); break
    token = r.get("paginationToken")
    if not token or len(d) < 100: break
json.dump(mints, open(SP + "/fp/ahw_failed.json", "w"))
print(f"{n} failed txs, {len(mints)} mints")
