# Rug protection: entry rules (skip at the create), trade-sequence rules (sell early), operator drops, and mixes, each
# scored per day on every bundled launch (the bot only buys those): a rule is real when it beats the plain hold on both days.
import json, glob, os, sys, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/fp")
from gib import mash
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
V0, T0 = 30e9, 1_073_000_000e6
L = []
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if not R or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]; full = next((s for s in OPS if s.startswith(s8)), None)
    if not full: continue                                   # the bot trades table operators only
    hold = int(OPS[full].get("hold_slots", 6))
    R = sorted([r for r in R if r["wallets"] >= 1], key=lambda r: r["t"])
    if not R: continue
    top_t = collections.Counter((r["dev"], tuple(r["bundle"])) for r in R).most_common(1)[0][0]
    t_mid = R[0]["t"] + (R[-1]["t"] - R[0]["t"]) / 2
    for i, r in enumerate(R):
        put = (r["dev"] + sum(r["bundle"])) * 1e9
        bought = T0 - V0 * T0 / (V0 + put / (1 + 0.0125))
        out_sol = lambda k: sum(e[4] for e in r["ev"] if e[3] and e[2] in ("o", "ahw") and e[0] <= k) / 1e9
        L.append(dict(op=s8, hold=hold, day=(1 if r["t"] < t_mid else 2), pnl=r["pnl"],
                      rug=sum(e[5] for e in r["ev"] if e[2] in ("dev", "bw") and not e[3] and e[0] < hold) >= 0.6 * bought,
                      off_tmpl=(r["dev"], tuple(r["bundle"])) != top_t,
                      relaunch=any(p["name"] == r["name"] and r["t"] - p["t"] < 3600 for p in R[:i]),
                      mash=mash(r["name"]) >= 0.5, fast=(i > 0 and r["t"] - R[i - 1]["t"] < 120),
                      out1=out_sol(1), out2=out_sol(2), out3=out_sol(3)))
def score(rule):
    """rule(l) -> None (skip: 0 SOL) or the hold to sell at."""
    d = {1: 0.0, 2: 0.0}; rug = 0.0; n = 0
    for l in L:
        h = rule(l)
        if h is None: continue
        v = l["pnl"][str(min(max(h, 1), 15))]; d[l["day"]] += v; n += 1
        if l["rug"]: rug += v
    return d[1], d[2], rug, n
base = score(lambda l: l["hold"])
print(f"{len(L)} bundled launches of table operators; rugs {sum(l['rug'] for l in L)}")
print(f"{'rule':<52}{'day 1':>9}{'day 2':>9}{'rugs':>9}{'trades':>7}  both days better?")
def show(name, rule):
    d1, d2, rg, n = score(rule)
    ok = d1 > base[0] and d2 > base[1]
    print(f"{name:<52}{d1:>+9.3f}{d2:>+9.3f}{rg:>+9.3f}{n:>7}  {'YES' if ok else 'no'}{'' if name != 'plain hold (now)' else ''}")
show("plain hold (now)", lambda l: l["hold"])
# entry rules
show("skip off-template launches", lambda l: None if l["off_tmpl"] else l["hold"])
show("skip relaunched names (1 h)", lambda l: None if l["relaunch"] else l["hold"])
show("skip keyboard-mash names", lambda l: None if l["mash"] else l["hold"])
show("skip < 2 min after the operator's last launch", lambda l: None if l["fast"] else l["hold"])
# trade-sequence rules: sell early when nobody outside buys
for k, x in ((1, 0.0), (1, 0.3), (2, 0.0), (2, 0.5), (3, 0.0), (3, 1.0)):
    show(f"sell at slot {k + 1} if outside buys by slot {k} <= {x} SOL", lambda l, k=k, x=x: (k + 1) if l[f"out{k}"] <= x and l["hold"] > k + 1 else l["hold"])
# operator drop decided on the other day: rugs cost more than its other launches made
def op_drop(fit_day):
    agg = collections.defaultdict(lambda: [0.0, 0.0])
    for l in L:
        if l["day"] == fit_day: agg[l["op"]][0 if l["rug"] else 1] += l["pnl"][str(l["hold"])]
    return {op for op, (rg, rest) in agg.items() if rg < 0 and -rg > rest}
d1_drop, d2_drop = op_drop(2), op_drop(1)          # day-1 trades use the day-2 decision and vice versa
show("drop operators whose rugs beat their profit (other day)", lambda l: None if l["op"] in (d1_drop if l["day"] == 1 else d2_drop) else l["hold"])
print("   dropped when fit on day 1:", sorted(d2_drop), " on day 2:", sorted(d1_drop))

# --- more trade-sequence rules: take profit, sell into a big outside buy
for y in (0.2, 0.4, 0.6, 1.0):
    def tp(l, y=y):
        for h in range(1, l["hold"] + 1):
            if l["pnl"][str(h)] >= y * 0.5: return h
        return l["hold"]
    show(f"take profit at +{int(y*100)}% (else hold)", tp)
EVS = {}
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    for r in json.load(open(f)):
        if "ev" in r: EVS[r["mint"]] = r["ev"]
mint_of = {}
i = 0
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if not R or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]; full = next((s for s in OPS if s.startswith(s8)), None)
    if not full: continue
    for r in sorted([r for r in R if r["wallets"] >= 1], key=lambda r: r["t"]):
        L[i]["ev"] = r["ev"]; L[i]["name"] = r["name"]; i += 1
for x in (1.0, 2.0, 3.0):
    def big(l, x=x):
        for e in l["ev"]:
            if e[0] >= l["hold"]: break
            if e[3] and e[2] in ("o", "ahw") and e[4] >= x * 1e9 and e[0] + 1 < l["hold"]: return e[0] + 1
        return l["hold"]
    show(f"sell next slot after an outside buy >= {x:.0f} SOL", big)

# --- per-operator rules: pick each operator's rule on one day, apply it on the other
CANDS = {"none": lambda l: False, "off_tmpl": lambda l: l["off_tmpl"], "relaunch": lambda l: l["relaunch"],
         "mash": lambda l: l["mash"], "fast": lambda l: l["fast"], "drop": lambda l: True}
def pick(day):
    by = collections.defaultdict(list)
    for l in L:
        if l["day"] == day: by[l["op"]].append(l)
    out = {}
    for op, ls in by.items():
        base_v = sum(l["pnl"][str(l["hold"])] for l in ls)
        best, best_v = "none", base_v
        for name, skip in CANDS.items():
            v = sum(l["pnl"][str(l["hold"])] for l in ls if not skip(l))
            if v > best_v + 0.05: best, best_v = name, v           # must clear 0.05 SOL on its day
        out[op] = best
    return out
p1, p2 = pick(1), pick(2)
show("per-operator skip rule (picked on the other day)", lambda l: None if CANDS[(p2 if l["day"] == 1 else p1).get(l["op"], "none")](l) else l["hold"])
print("   picked on day 1:", {k: v for k, v in sorted(p1.items()) if v != "none"})
print("   picked on day 2:", {k: v for k, v in sorted(p2.items()) if v != "none"})
show("mix: skip mash names + per-operator rule", lambda l: None if l["mash"] or CANDS[(p2 if l["day"] == 1 else p1).get(l["op"], "none")](l) else l["hold"])
