# keyboard-mash score: share of consecutive letter pairs typed on the same or neighbouring QWERTY keys
ROWS = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
POS = {c: (r, i + 0.5 * r) for r, row in enumerate(ROWS) for i, c in enumerate(row)}
def mash(name):
    s = [c for c in (name or "").lower() if c in POS or c == " "]
    pairs = [(a, b) for a, b in zip(s, s[1:]) if a != " " and b != " "]
    if len(pairs) < 3: return 0.0
    near = sum(1 for a, b in pairs if abs(POS[a][0] - POS[b][0]) <= 1 and abs(POS[a][1] - POS[b][1]) <= 1.0)
    return near / len(pairs)
def gibberish(name, sym=""):
    return mash(name) >= 0.55
if __name__ == "__main__":
    for n in ["fgfggr r", "y ryfghf", "bragawattsdaw daw", "dwadawda", "wdada", "NASDANK 4200", "INFINITY GAUNTLET", "Tesla Strategy",
              "CRIMEN ES LEGAL", "Fartcoin", "Chungus", "HyperPlex", "PUMPVENGERS", "the sky is falling", "Mecha Kitty", "kumchi",
              "You Missed Bitches", "Official Netanyahu", "BILS", "urmom coin", "Dividend Dog", "asd as", "grrg rg", "Solana Monet"]:
        print(f"{mash(n):.2f} {gibberish(n)!s:<5} {n}")
