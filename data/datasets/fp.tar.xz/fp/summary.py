# Per-operator tailoring from fp/<signer8>.json: EV for the first spot behind the bundle by hold (whole 48 h, and each
# 24 h half on its own), the hold chosen on the first half and scored on the second, rug fingerprint (full rugs:
# the creator set sells >= 60% of what it put in within the hold), and how the launches we won compare.
import json, glob, os, re, statistics as st, collections, time, sys
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
HOLDS = [str(h) for h in range(1, 16)]
VOW = set("aeiouyAEIOUY")
def gibberish(name):
    w = re.sub(r"[^A-Za-z ]", "", name or "").strip()
    if not w or len(w) < 4: return False
    words = w.split()
    # keyboard mash: few vowels, letters repeated from one keyboard row, or no dictionary-ish shape
    v = sum(c in VOW for c in w if c != " ") / max(1, sum(c != " " for c in w))
    rowmash = all(set(x.lower()) <= set("qwertyuiop") or set(x.lower()) <= set("asdfghjkl") or set(x.lower()) <= set("zxcvbnm") for x in words)
    return v < 0.2 or rowmash
out = []
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue          # <signer8>.json only
    R = json.load(open(f))
    if not R: continue
    sig8 = os.path.basename(f)[:8]
    full = next((s for s in OPS if s.startswith(sig8)), sig8)
    R.sort(key=lambda r: r["t"])
    mid = R[0]["t"] + (R[-1]["t"] - R[0]["t"]) / 2
    a, b = [r for r in R if r["t"] < mid], [r for r in R if r["t"] >= mid]
    ev = {h: st.mean(r["pnl"][h] for r in R) for h in HOLDS}
    best = max(HOLDS, key=lambda h: ev[h])
    best_a = max(HOLDS, key=lambda h: st.mean(r["pnl"][h] for r in a)) if a else best
    oos = st.mean(r["pnl"][best_a] for r in b) if b else None
    table_hold = str((OPS.get(full) or {}).get("hold_slots") or 6)
    put = lambda r: r["dev"] + sum(r["bundle"])
    rug = lambda r, h: r["first_dump"] is not None and r["first_dump"] < int(h) and r["dump_sol"] >= 0.6 * put(r)
    gib = [r for r in R if gibberish(r["name"])]
    us = [r for r in R if r["first_is"] == "us"]
    out.append(dict(op=full, n=len(R), per_h=len(R) / 48, in_table=full in OPS, table_hold=int(table_hold),
                    ev_table=ev[table_hold], best=int(best), ev_best=ev[best], best_a=int(best_a), oos=oos,
                    med=st.median(r["pnl"][best] for r in R), win=sum(r["pnl"][best] > 0 for r in R) / len(R),
                    rugs=sum(rug(r, best) for r in R), gib=len(gib), gib_rugs=sum(rug(r, best) for r in gib),
                    gib_ev=(st.mean(r["pnl"][best] for r in gib) if gib else None),
                    ev_no_gib=(st.mean(r["pnl"][best] for r in R if not gibberish(r["name"])) if len(gib) < len(R) else None),
                    us_n=len(us), us_ev=(st.mean(r["pnl"][best] for r in us) if us else None),
                    first_share={k: sum(1 for r in R if r["first_is"] == k) for k in ("us", "ahw", "other", "none")},
                    templates=len({(r["dev"], tuple(r["bundle"])) for r in R})))
out.sort(key=lambda o: -o["n"] * o["ev_best"])
json.dump(out, open(SP + "/fp/summary.json", "w"), indent=1)
print(f"{'operator':<10}{'tbl':>4}{'n':>5}{'/h':>5} {'hold':>4}{'EV@hold':>9} {'best':>4}{'EV@best':>9}{'OOS':>8} {'win':>4} {'rugs':>4} {'gib':>3}/{'r':<2}{'EVnoGib':>8} {'we1st':>5}{'ourEV':>8}  first us/ahw/oth")
for o in out:
    f = o["first_share"]
    print(f"{o['op'][:8]:<10}{'yes' if o['in_table'] else '-':>4}{o['n']:>5}{o['per_h']:>5.1f} {o['table_hold']:>4}{o['ev_table']:>+9.4f} {o['best']:>4}{o['ev_best']:>+9.4f}{(o['oos'] if o['oos'] is not None else float('nan')):>+8.4f} {100*o['win']:>3.0f}% {o['rugs']:>4} {o['gib']:>3}/{o['gib_rugs']:<2}{(o['ev_no_gib'] if o['ev_no_gib'] is not None else float('nan')):>+8.4f} {o['us_n']:>5}{(o['us_ev'] if o['us_ev'] is not None else float('nan')):>+8.4f}  {f['us']}/{f['ahw']}/{f['other']}")
