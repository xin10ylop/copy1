# Exit rules against rugs, replayed on every stored launch (fp/<signer8>.json with "ev"): our 0.5 SOL position takes the
# first spot behind the bundle; the real first buyer and our own trades are replaced by it.
import json, glob, os, sys, statistics as st, collections
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
STAKE, FEE, COSTS = 0.5, 0.0125, 0.0094
def replay(r, hold, rule):
    """-> P&L (SOL) of the position under `rule` = (kind, param) with a hard exit at `hold` slots after the create."""
    v, tk = float(r["post_v"]) * 1e9, float(r["post_t"])
    s_in = STAKE * 1e9 / (1 + FEE); v2 = v + s_in; q = tk - v * tk / v2; tk = v * tk / v2; v = v2
    entry_price = s_in / q
    cs_bought = None
    kind, par = rule
    pending_exit_slot = None
    for e in r["ev"]:
        off, idx, role, isbuy, sol, tok = e[0], e[1], e[2], e[3], e[4], e[5]
        if role in ("us", "first"): continue
        if off >= hold: break
        if pending_exit_slot is not None and off >= pending_exit_slot: break
        k = v * tk
        if isbuy: v = v + sol; tk = k / v
        else: tk = tk + tok; v = k / tk
        if role in ("dev", "bw") and not isbuy and pending_exit_slot is None:
            big = True
            if kind == "react_big":
                # the sell's tokens against everything the creator set bought (dev + bundle): >= par
                bought = r["post_t_bought"] if "post_t_bought" in r else None
                big = bought is None or tok >= par * bought
            if kind in ("react_next", "react_big") and big:
                pending_exit_slot = off + 1                     # we sell before any trade of the next slot
            elif kind == "react_now" and big:
                break                                          # we sell right behind this sell (same slot)
        if kind == "stop":
            price = v / tk
            if price < entry_price * (1 - par) and pending_exit_slot is None:
                pending_exit_slot = off + 1
    v_new = v * tk / (tk + q); out = (v - v_new) * (1 - FEE) / 1e9
    return out - STAKE - COSTS
RULES = [("hold", 0), ("react_next", 0), ("react_now", 0), ("react_big", 0.3), ("react_big", 0.6), ("stop", 0.3), ("stop", 0.5)]
rows = []
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if not R or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]
    full = next((s for s in OPS if s.startswith(s8)), None)
    hold = (OPS.get(full) or {}).get("hold_slots", 6) if full else 6
    for r in R:
        # the creator set's tokens: the bundle run's buys, from the curve (dev + bundle SOL at the curve's start)
        V0, T0 = 30e9, 1_073_000_000e6
        put = (r["dev"] + sum(r["bundle"])) * 1e9
        r["post_t_bought"] = T0 - V0 * T0 / (V0 + put / (1 + FEE))
        sells = sum(e[5] for e in r["ev"] if e[2] in ("dev", "bw") and not e[3] and e[0] < hold)
        rug = sells >= 0.6 * r["post_t_bought"]
        rows.append(dict(op=s8, in_table=bool(full), hold=hold, t=r["t"], rug=rug, res={f"{k}:{p}": replay(r, hold, (k, p)) for k, p in RULES}))
print(f"{len(rows)} launches of {len({r['op'] for r in rows})} operators; full rugs within the table hold: {sum(r['rug'] for r in rows)}")
for scope, sel in (("all launches", lambda r: True), ("table operators", lambda r: r["in_table"]), ("rugs only", lambda r: r["rug"]), ("non-rugs", lambda r: not r["rug"])):
    rs = [r for r in rows if sel(r)]
    if not rs: continue
    print(f"\n{scope} (n {len(rs)}): total SOL per rule")
    for k, p in RULES:
        key = f"{k}:{p}"
        print(f"   {key:<16} total {sum(r['res'][key] for r in rs):+8.3f}   mean {st.mean(r['res'][key] for r in rs):+.4f}")
