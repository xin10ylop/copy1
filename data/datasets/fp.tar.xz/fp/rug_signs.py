# What a rug looks like at the create, per operator: the launches whose creator set sold >= 60% of what it bought within
# the table hold, against that operator's other launches, on facts the bot can see before it buys.
import json, glob, os, sys, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
sys.path.insert(0, SP + "/fp")
from gib import mash
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
def sym_in_name(r):
    n = "".join(c for c in (r["name"] or "").lower() if c.isalnum()); s = "".join(c for c in (r["sym"] or "").lower() if c.isalnum())
    return bool(s) and (s in n or all(c in n for c in s))
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if len(R) < 6 or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]; full = next((s for s in OPS if s.startswith(s8)), None)
    hold = (OPS.get(full) or {}).get("hold_slots", 6) if full else 6
    R.sort(key=lambda r: r["t"])
    V0, T0 = 30e9, 1_073_000_000e6
    for i, r in enumerate(R):
        put = (r["dev"] + sum(r["bundle"])) * 1e9
        bought = T0 - V0 * T0 / (V0 + put / (1 + 0.0125))
        r["rug"] = sum(e[5] for e in r["ev"] if e[2] in ("dev", "bw") and not e[3] and e[0] < hold) >= 0.6 * bought
        r["relaunch"] = sum(1 for p in R[:i] if p["name"] == r["name"] and r["t"] - p["t"] < 3600)
        r["gap_min"] = (r["t"] - R[i - 1]["t"]) / 60 if i else None
        r["mash"] = mash(r["name"])
        r["sym_ok"] = sym_in_name(r)
        r["tmpl"] = (r["dev"], tuple(r["bundle"]))
    rugs = [r for r in R if r["rug"]]; ok = [r for r in R if not r["rug"]]
    if len(rugs) < 2: continue
    print(f"\n{s8} {'(table)' if full else ''}  launches {len(R)}  rugs {len(rugs)} within hold {hold}")
    top_t = collections.Counter(r["tmpl"] for r in R).most_common(1)[0][0]
    for name, fn in (("mash score >= 0.5", lambda r: r["mash"] >= 0.5), ("symbol not from the name", lambda r: not r["sym_ok"]),
                     ("relaunch of a name (1 h)", lambda r: r["relaunch"] > 0), ("not the usual template", lambda r: r["tmpl"] != top_t),
                     ("< 2 min after its last launch", lambda r: r["gap_min"] is not None and r["gap_min"] < 2),
                     ("no follower buy in slot 0-1", lambda r: not any(e[3] and e[2] == "o" and e[0] <= 1 for e in r["ev"]))):
        a = sum(fn(r) for r in rugs); b = sum(fn(r) for r in ok)
        flag = "  <== separates" if a / len(rugs) >= 0.6 and b / max(1, len(ok)) <= 0.2 else ""
        print(f"   {name:<32} rugs {a}/{len(rugs)}  others {b}/{len(ok)}{flag}")
    for r in rugs:
        print(f"      rug: {r['mint'][:8]} {r['name'][:26]!r:<28} {r['sym'][:10]!r:<12} mash {r['mash']:.2f} relaunch {r['relaunch']} tmpl dev {r['dev']} b{sum(r['bundle']):.2f}")
