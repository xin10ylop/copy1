# Robustness of the sell-clock exit: other thresholds, offsets, minimum shares; and which operators carry the gain.
import json, glob, os, collections, statistics as st
SP = "/tmp/claude-0/-home-user-rugsnipe/972c43cf-f494-5af4-b87a-fe32117a83be/scratchpad"
OPS = json.load(open("/home/user/rugsnipe/data/operators/ahw-2026-10-24-tier.json"))
V0, T0 = 30e9, 1_073_000_000e6
ops = {}
for f in sorted(glob.glob(SP + "/fp/*.json")):
    if len(os.path.basename(f)) != 13: continue
    R = json.load(open(f))
    if not R or "ev" not in R[0]: continue
    s8 = os.path.basename(f)[:8]; full = next((s for s in OPS if s.startswith(s8)), None)
    if not full: continue
    R = sorted([r for r in R if r["wallets"] >= 1], key=lambda r: r["t"])
    if len(R) < 10: continue
    mid = R[0]["t"] + (R[-1]["t"] - R[0]["t"]) / 2
    for r in R:
        put = (r["dev"] + sum(r["bundle"])) * 1e9; r["bought"] = T0 - V0 * T0 / (V0 + put / 1.0125)
        r["day"] = 1 if r["t"] < mid else 2
    ops[s8] = (int(OPS[full].get("hold_slots", 6)), R)
def sell_slot(r, thr):
    cum = 0.0
    for e in r["ev"]:
        if e[2] in ("dev", "bw") and not e[3]:
            cum += e[5]
            if cum >= thr * r["bought"]: return e[0]
    return None
def run(thr, off, min_share, detail=False):
    tot = {1: 0.0, 2: 0.0}; base = {1: 0.0, 2: 0.0}; per = collections.defaultdict(float)
    for s8, (th, R) in ops.items():
        for fit, test in ((1, 2), (2, 1)):
            a = [r for r in R if r["day"] == fit]; b = [r for r in R if r["day"] == test]
            if len(a) < 5 or len(b) < 5: continue
            ss = [x for x in (sell_slot(r, thr) for r in a) if x is not None]
            h = int(max(2, min(15, st.median(ss) - off))) if ss and len(ss) / len(a) >= min_share else th
            v = sum(r["pnl"][str(h)] for r in b); v0 = sum(r["pnl"][str(th)] for r in b)
            tot[test] += v; base[test] += v0; per[s8] += v - v0
    return tot, base, per
print(f"{'threshold':>9} {'offset':>6} {'min share':>9} {'day 1':>9} {'(now)':>8} {'day 2':>9} {'(now)':>8}  both better?")
for thr in (0.1, 0.25, 0.5):
    for off in (0, 1, 2):
        for ms in (0.2, 1 / 3, 0.5):
            t, b, _ = run(thr, off, ms)
            print(f"{thr:>9.2f} {off:>6} {ms:>9.2f} {t[1]:>+9.3f} {b[1]:>+8.3f} {t[2]:>+9.3f} {b[2]:>+8.3f}  {'YES' if t[1] > b[1] and t[2] > b[2] else 'no'}")
_, _, per = run(0.25, 1, 1 / 3)
print("\nwho carries the gain (threshold 25%, one slot before, sold in >= 1/3), both test days summed, SOL:")
for s8, g in sorted(per.items(), key=lambda kv: -kv[1]):
    if abs(g) > 0.02: print(f"  {s8} {g:+.3f}")
print(f"  operators better: {sum(g > 0.005 for g in per.values())}, worse: {sum(g < -0.005 for g in per.values())}, same: {sum(abs(g) <= 0.005 for g in per.values())}")

# the split: the operator's own clock where the best wallet's hold rests on few of his trades, his hold otherwise
NS = {s8: int((OPS.get(next((s for s in OPS if s.startswith(s8)), ""), {}) or {}).get("n", 0)) for s8 in ops}
def run_split(n0, thr=0.25, off=1, min_share=1 / 3, min_launches=20):
    tot = {1: 0.0, 2: 0.0}; base = {1: 0.0, 2: 0.0}; changed = set()
    rug_t = {1: 0.0, 2: 0.0}; rest_t = {1: 0.0, 2: 0.0}; rug_b = {1: 0.0, 2: 0.0}; rest_b = {1: 0.0, 2: 0.0}
    for s8, (th, R) in ops.items():
        for fit, test in ((1, 2), (2, 1)):
            a = [r for r in R if r["day"] == fit]; b = [r for r in R if r["day"] == test]
            if len(a) < 5 or len(b) < 5: continue
            h = th
            ss = [x for x in (sell_slot(r, thr) for r in a) if x is not None]
            if NS[s8] < n0 and len(a) >= min_launches / 2 and ss and len(ss) / len(a) >= min_share:
                h = int(max(2, min(15, st.median(ss) - off))); changed.add(s8)
            for r in b:
                put = (r["dev"] + sum(r["bundle"])) * 1e9
                rug = sum(e[5] for e in r["ev"] if e[2] in ("dev", "bw") and not e[3] and e[0] < th) >= 0.6 * r["bought"]
                v, v0 = r["pnl"][str(h)], r["pnl"][str(th)]
                tot[test] += v; base[test] += v0
                (rug_t if rug else rest_t)[test] += v; (rug_b if rug else rest_b)[test] += v0
    return tot, base, changed, (rug_t, rest_t, rug_b, rest_b)
print("\nsplit rule: own clock (25%, one slot before, sold in >= 1/3) where the best wallet's n is below N, his hold otherwise")
for n0 in (3, 5, 10, 20, 1000):
    t, b, ch, (rt, st_, rb, sb) = run_split(n0)
    print(f"  N {n0:>4}: day 1 {t[1]:+.3f} (now {b[1]:+.3f})  day 2 {t[2]:+.3f} (now {b[2]:+.3f})  rugs {rt[1]+rt[2]:+.2f} (now {rb[1]+rb[2]:+.2f})  rest {st_[1]+st_[2]:+.2f} (now {sb[1]+sb[2]:+.2f})  operators changed {len(ch)}  {'BOTH BETTER' if t[1] > b[1] and t[2] > b[2] else ''}")
t, b, ch, _ = run_split(10)
print("  changed at N 10:", sorted(ch), {s8: NS[s8] for s8 in sorted(ch)})
